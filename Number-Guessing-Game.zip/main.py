import random

# random number between 1 and 6
number = random.randint(1, 6)

print("Welcome to the Game!")
print("You have 3 attempts to guess the correct number between 1 and 6.")

# Loop for three attempts
for attempt in range(3):
    print("Attempt", attempt + 1)
    guess = input("Enter your guess: ")

    # Validate input
    if not guess.isdigit():
        print("Invalid input. Please enter a valid number.")
        continue

    guess = int(guess)

    # Check if correct
    if guess == number:
        print("Congratulations! You guessed correctly!")
        break
    elif guess < 1 or guess > 6:
        print("Please enter a number between 1 and 6.")
    elif guess > number and attempt <2:
        print("Your guess is too high.")
    elif guess < number and attempt <2:
        print("Your guess is too low.")

    if attempt == 2 and guess != number:
        print("Sorry, you have used all your attempts. The correct number was", number)
        break
      #the above code  elif guess < number and attempt <2: is what prints if the user guesses the number wrong and the attempt is less than attempt 2 if above 2 it dose not output anything.